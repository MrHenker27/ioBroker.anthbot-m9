'use strict';

/** @type {typeof import('@iobroker/adapter-core')} */
const utils = require('@iobroker/adapter-core');
const axios = /** @type {import('axios').AxiosStatic} */ (/** @type {unknown} */ (require('axios')));
const { AnthbotCloudApiClient } = require('./lib/anthbot/cloud-client');
const { AnthbotShadowApiClient } = require('./lib/anthbot/shadow-client');
const {
    AnthbotGenieError,
    asInteger,
    deviceObjectIdFromSerial,
    isLikelyAuthenticationError,
} = require('./lib/anthbot/utils');
const {
    BOOLEAN_COMMANDS,
    MAINTENANCE_RESET_TYPES,
    STRING_COMMANDS,
    getDeviceChannelDefinitions,
    getDeviceStateDefinitions,
} = require('./lib/adapter/definitions');
const { generalMowerStatus, isCharging } = require('./lib/anthbot/payload');
'use strict';

const DEFAULT_ACTIVE_POLL_INTERVAL_SECONDS = 30;
const DEFAULT_CHARGING_POLL_INTERVAL_SECONDS = 300;
const DEFAULT_IDLE_POLL_INTERVAL_SECONDS = 900;

const MIN_POLL_INTERVAL_SECONDS = 15;
const MAX_POLL_INTERVAL_SECONDS = 3600;

/**
 * @param {string|number|null|undefined} value
 * @param {number} defaultValue
 * @returns {number}
 */
function normalizePollIntervalSeconds(value, defaultValue) {
    const parsed = Number(value);
    const intervalSeconds = Number.isFinite(parsed) && parsed > 0 ? parsed : defaultValue;

    return Math.min(
        MAX_POLL_INTERVAL_SECONDS,
        Math.max(MIN_POLL_INTERVAL_SECONDS, intervalSeconds),
    );
}

module.exports = {
    DEFAULT_ACTIVE_POLL_INTERVAL_SECONDS,
    DEFAULT_CHARGING_POLL_INTERVAL_SECONDS,
    DEFAULT_IDLE_POLL_INTERVAL_SECONDS,
    MAX_POLL_INTERVAL_SECONDS,
    MIN_POLL_INTERVAL_SECONDS,
    normalizePollIntervalSeconds,
};
const { buildDeviceStateUpdates, getControlFallbackValue } = require('./lib/adapter/state-updates');
const { executeCommand, executeConsumableCommand, executeControl } = require('./lib/adapter/actions');

/**
 * @typedef {object} AnthbotAdapterConfig
 * @property {string} username
 * @property {string} password
 * @property {string} areaCode
 * @property {string} apiHost
 * @property {number} pollInterval
 * @property {string} errorDescriptionLanguage
 */

/** @typedef {ioBroker.Adapter} IoBrokerAdapter */
/** @typedef {new (options: ioBroker.AdapterOptions | string) => IoBrokerAdapter} AdapterCtor */

const AdapterBase = /** @type {AdapterCtor} */ (utils.Adapter);
const { I18n } = utils;

function t(en) {
    return I18n.getTranslatedObject(en);
}

class AnthbotGenieAdapter extends AdapterBase {
    constructor(options = {}) {
        super({
            ...options,
            name: 'anthbot-m9',
        });

        this.on('ready', this.onReady.bind(this));
        this.on('stateChange', this.onStateChange.bind(this));
        this.on('unload', this.onUnload.bind(this));

        this.http = null;
        this.cloudClient = null;
        this.authToken = null;
        this.deviceContexts = new Map();
        this.deviceContextsByObjectRoot = new Map();
        this.eventCodeCache = null;
        this.eventCodeCacheInitialized = false;
        this.pollTimer = null;
        this.refreshInFlight = null;
        this.unloaded = false;
    }

    /**
     * @returns {AnthbotAdapterConfig}
     */
    get anthbotConfig() {
        return /** @type {AnthbotAdapterConfig} */ (this.config);
    }

    async onReady() {
        this.unloaded = false;
        const config = this.anthbotConfig;
        this.http = axios.create({
            timeout: 15000,
            validateStatus: () => true,
        });

        await I18n.init(__dirname, this);
        await this.ensureBaseObjects();
        await this.setStateAsync('info.connection', false, true);

        if (!config.username || !config.password) {
            this.log.error('Username and password must be configured.');
            return;
        }

        this.subscribeStates('*.commands.*');
        this.subscribeStates('*.controls.*');
        this.subscribeStates('*.consumable.*.reset');

        await this.refreshAll(true);
        this.schedulePoll();
    }

    async ensureBaseObjects() {
        await this.extendObjectAsync('info', {
            type: 'channel',
            common: {
                name: t('Info'),
            },
            native: {},
        });

        await this.extendObjectAsync('info.connection', {
            type: 'state',
            common: {
                name: t('Cloud connection'),
                type: 'boolean',
                role: 'indicator.connected',
                read: true,
                write: false,
                def: false,
            },
            native: {},
        });
    }

    onUnload(callback) {
        try {
            this.unloaded = true;
            if (this.pollTimer) {
                this.clearTimeout(this.pollTimer);
                this.pollTimer = null;
            }
            callback();
        } catch {
            callback();
        }
    }

        schedulePoll() {
        if (this.unloaded) {
            return;
        }

        if (this.pollTimer) {
            this.clearTimeout(this.pollTimer);
        }

        const contexts = Array.from(this.deviceContexts.values());

        const anyCharging = contexts.some(context =>
           isCharging(context.lastReported || {}),
        );

        const activeStatuses = new Set([
            'mowing',
            'returning_to_dock',
            'mapping',
            'positioning',
            'resuming',
            'remote_control',
            'going_to_target',
         ]);

        const anyActive = contexts.some(context =>
            activeStatuses.has(
                generalMowerStatus(context.lastReported || {}),
            ),
        );

        let intervalSeconds;

        if (anyActive) {
            intervalSeconds = normalizePollIntervalSeconds(
                this.anthbotConfig.pollIntervalActive,
                DEFAULT_ACTIVE_POLL_INTERVAL_SECONDS,
            );
        } else if (anyCharging) {
            intervalSeconds = normalizePollIntervalSeconds(
                this.anthbotConfig.pollIntervalCharging,
                DEFAULT_CHARGING_POLL_INTERVAL_SECONDS,
            );
        } else {
            intervalSeconds = normalizePollIntervalSeconds(
                this.anthbotConfig.pollIntervalIdle,
                DEFAULT_IDLE_POLL_INTERVAL_SECONDS,
            );
        }

        this.pollTimer = this.setTimeout(async () => {
            this.pollTimer = null;

            try {
                await this.refreshAll();
            } finally {
                if (!this.unloaded) {
                    this.schedulePoll();
                }
            }
        }, intervalSeconds * 1000);
    }

    async refreshAll(forceLogin = false) {
        if (this.refreshInFlight) {
            return this.refreshInFlight;
        }
        this.refreshInFlight = this.doRefreshAll(forceLogin).finally(() => {
            this.refreshInFlight = null;
        });
        return this.refreshInFlight;
    }

    async doRefreshAll(forceLogin = false) {
        return this.runRefreshCycle(forceLogin, false);
    }

    async runRefreshCycle(forceLogin, retriedAfterAuthFailure) {
        let successful = 0;
        try {
            await this.ensureSession(forceLogin);
            await this.discoverDevices(forceLogin);
            await this.ensureEventCodeCache();
            for (const context of this.deviceContexts.values()) {
                try {
                    await this.refreshDevice(context);
                    successful += 1;
                } catch (error) {
                    this.log.warn(`Refresh failed for ${context.device.serialNumber}: ${error.stack || JSON.stringify(error) || String(error)}`);
                }
            }
        } catch (error) {
            if (!retriedAfterAuthFailure && !forceLogin && isLikelyAuthenticationError(error)) {
                this.log.info('Anthbot cloud session expired, retrying refresh with a new login.');
                return this.runRefreshCycle(true, true);
            }
            this.log.error(`Global refresh failed: ${error.message}`);
        }

        await this.setStateAsync('info.connection', successful > 0, true);
    }

    async ensureEventCodeCache() {
        if (this.eventCodeCacheInitialized) {
            return;
        }
        this.eventCodeCacheInitialized = true;

        const cached = await this.readStoredEventCodeCache();
        this.eventCodeCache = cached;

        let cloudVersion = null;
        try {
            cloudVersion = await this.cloudClient.getEventCodeVersion();
        } catch (error) {
            if (cached) {
                this.log.warn(`Failed to fetch event code version, using cached translations: ${error.message}`);
                await this.writeEventCodeCacheToDevices(cached);
            } else {
                this.log.warn(
                    `Failed to fetch event code version and no cached translations are available: ${error.message}`,
                );
            }
            return;
        }

        if (cached && asInteger(cached.version) === cloudVersion) {
            this.eventCodeCache = cached;
            await this.writeEventCodeCacheToDevices(cached);
            return;
        }

        try {
            const payload = await this.cloudClient.getEventCodeTranslations(cloudVersion);
            this.eventCodeCache = {
                version: cloudVersion,
                fetchedAt: new Date().toISOString(),
                payload,
            };
            await this.writeEventCodeCacheToDevices(this.eventCodeCache);
        } catch (error) {
            if (cached) {
                this.log.warn(`Failed to fetch event code translations, using cached translations: ${error.message}`);
                this.eventCodeCache = cached;
                await this.writeEventCodeCacheToDevices(cached);
            } else {
                this.log.warn(
                    `Failed to fetch event code translations and no cached translations are available: ${error.message}`,
                );
            }
        }
    }

    async readStoredEventCodeCache() {
        for (const context of this.deviceContexts.values()) {
            const root = context.objectRoot;
            try {
                const state = await this.getStateAsync(`${root}.raw.shadow.event-code`);
                const raw = typeof state?.val === 'string' ? state.val : '';
                if (!raw) {
                    continue;
                }
                const parsed = JSON.parse(raw);
                if (this.isValidEventCodeCache(parsed)) {
                    return parsed;
                }
            } catch (error) {
                this.log.debug(
                    `Stored event code cache could not be read for ${context.device.serialNumber}: ${error.message}`,
                );
            }
        }
        return null;
    }

    isValidEventCodeCache(cache) {
        return Boolean(
            cache &&
            typeof cache === 'object' &&
            asInteger(cache.version) != null &&
            cache.payload &&
            typeof cache.payload === 'object' &&
            !Array.isArray(cache.payload),
        );
    }

    async writeEventCodeCacheToDevices(cache) {
        if (!cache) {
            return;
        }
        const value = JSON.stringify(cache);
        for (const context of this.deviceContexts.values()) {
            await this.setStateAsync(`${context.objectRoot}.raw.shadow.event-code`, { val: value, ack: true });
        }
    }

    async ensureSession(force = false) {
        const config = this.anthbotConfig;
        if (!this.cloudClient || force) {
            this.cloudClient = new AnthbotCloudApiClient({
                http: this.http,
                host: config.apiHost || 'api.anthbot.com',
                bearerToken: force ? null : this.authToken,
            });
        }
        if (!this.authToken || force) {
            this.authToken = await this.cloudClient.login({
                username: config.username,
                password: config.password,
                areaCode: String(config.areaCode || '49'),
            });
        }
    }

    async discoverDevices(force = false) {
        if (this.deviceContexts.size > 0 && !force) {
            return;
        }

        const devices = await this.cloudClient.getBoundDevices();
        if (!devices.length) {
            throw new AnthbotGenieError('No Anthbot devices found for this account');
        }

        const seenSerials = new Set(devices.map(device => device.serialNumber));
        await this.removeStaleDeviceContexts(seenSerials);

        for (const device of devices) {
            const region = await this.resolveDeviceRegion(device);
            const existing = this.deviceContexts.get(device.serialNumber);
            const objectRoot = deviceObjectIdFromSerial(device.serialNumber, this.FORBIDDEN_CHARS);
            const context = {
                device,
                objectRoot,
                region,
                shadowClient: region.iotCredentials
                    ? this.buildShadowClient(device, region, region.iotCredentials)
                    : null,
                iotCredentials: region.iotCredentials,
                areaDefinition: existing?.areaDefinition || {},
                lastAreaTime: existing?.lastAreaTime || null,
                lastReported: existing?.lastReported || {},
                lastService: existing?.lastService || {},
            };
            this.deviceContexts.set(device.serialNumber, context);
            this.deviceContextsByObjectRoot.set(objectRoot, context);
            await this.ensureDeviceObjects(context);
        }
    }

    async resolveDeviceRegion(device) {
        let regionName = null;
        let iotEndpoint = null;
        let iotCredentials = null;

        try {
            const deviceRegion = await this.cloudClient.getDeviceRegion(device.serialNumber);
            regionName = deviceRegion.regionName;
            iotEndpoint = deviceRegion.iotEndpoint;
        } catch (error) {
            this.log.warn(
                `Failed to fetch region metadata for ${device.serialNumber}, using fallback discovery: ${error.message}`,
            );
        }

        try {
            const fallbackRegion = await this.cloudClient.getDevicePresignedRegion(device.serialNumber);
            if (fallbackRegion) {
                if (!regionName) {
                    regionName = fallbackRegion;
                }
                if (!iotEndpoint && !fallbackRegion.startsWith('cn')) {
                    iotEndpoint = AnthbotShadowApiClient.buildDefaultIotEndpointForRegion(fallbackRegion);
                } else if (iotEndpoint && !fallbackRegion.startsWith('cn')) {
                    const endpointRegion = AnthbotShadowApiClient.guessRegionFromEndpoint(iotEndpoint);
                    if (endpointRegion && endpointRegion !== fallbackRegion) {
                        regionName = fallbackRegion;
                        iotEndpoint = AnthbotShadowApiClient.buildDefaultIotEndpointForRegion(fallbackRegion);
                        this.log.debug(
                            `Overriding mismatched region metadata for ${device.serialNumber}: region=${regionName}, endpoint=${iotEndpoint}`,
                        );
                    }
                }
            }
        } catch (error) {
            this.log.debug(`Presigned region fallback failed for ${device.serialNumber}: ${error.message}`);
        }

        try {
            iotCredentials = await this.cloudClient.getDeviceIotCredentials(device.serialNumber);
            regionName = iotCredentials.regionName || regionName;
            iotEndpoint = iotCredentials.endpoint || iotEndpoint;
        } catch (error) {
            this.log.warn(
                `Failed to fetch temporary IoT credentials for ${device.serialNumber}; shadow access is unavailable until STS succeeds again: ${error.message}`,
            );
        }

        return {
            serialNumber: device.serialNumber,
            regionName: regionName || AnthbotShadowApiClient.guessRegionFromEndpoint(iotEndpoint) || 'unknown',
            iotEndpoint,
            iotCredentials,
        };
    }

    async removeStaleDeviceContexts(seenSerials) {
        for (const serial of this.deviceContexts.keys()) {
            if (seenSerials.has(serial)) {
                continue;
            }
            const context = this.deviceContexts.get(serial);
            this.deviceContexts.delete(serial);
            if (context?.objectRoot) {
                this.deviceContextsByObjectRoot.delete(context.objectRoot);
            }
            try {
                await this.delObjectAsync(
                    context?.objectRoot || deviceObjectIdFromSerial(serial, this.FORBIDDEN_CHARS),
                    { recursive: true },
                );
                this.log.info(`Removed stale device objects for ${serial}.`);
            } catch (error) {
                this.log.warn(`Failed to remove stale device objects for ${serial}: ${error.message}`);
            }
        }
    }

    async ensureDeviceObjects(context) {
        const serial = context.device.serialNumber;
        const root = context.objectRoot;

        await this.extendObjectAsync(root, {
            type: 'device',
            common: {
                name: context.device.alias,
            },
            native: {
                serialNumber: serial,
            },
        });

        for (const [id, type, name] of getDeviceChannelDefinitions(t)) {
            await this.extendObjectAsync(`${root}.${id}`, {
                type,
                common: { name },
                native: {},
            });
        }

        for (const [suffix, common] of Object.entries(getDeviceStateDefinitions(t))) {
            await this.extendObjectAsync(`${root}.${suffix}`, {
                type: 'state',
                common,
                native: {},
            });
        }
    }

    async refreshDevice(context) {
        await this.ensureDeviceIotCredentials(context);
        if (!context.shadowClient) {
            throw new AnthbotGenieError(
                `Skipping ${context.device.serialNumber}: temporary IoT credentials are unavailable for shadow access`,
            );
        }
        const propertyState = await context.shadowClient.getShadowReportedState();
        let serviceState = {};
        try {
            serviceState = await context.shadowClient.getServiceReportedState();
        } catch (error) {
            this.log.debug(`Service shadow failed for ${context.device.serialNumber}: ${error.message}`);
        }

        const areaTime = typeof propertyState.area_time === 'string' ? propertyState.area_time : null;
        const shouldRefreshArea =
            !context.areaDefinition ||
            Object.keys(context.areaDefinition).length === 0 ||
            (areaTime && areaTime !== context.lastAreaTime);
        if (shouldRefreshArea) {
            try {
                const map = await this.cloudClient.getDeviceMap(context.device.serialNumber);
                context.areaDefinition = map.areaDefinition;
                context.mapData = map.mapData;
                context.lastAreaTime = areaTime;
            } catch (error) {
                if (isLikelyAuthenticationError(error)) {
                    await this.ensureSession(true);
                    const map = await this.cloudClient.getDeviceMap(
                        context.device.serialNumber,
                    );
                    context.areaDefinition = map.areaDefinition;
                    context.mapData = map.mapData;
                    context.lastAreaTime = areaTime;
                } else {
                    this.log.debug(
                        `Area definition refresh failed for ${context.device.serialNumber}: ${error.message}`,
                    );
                }
            }
        }

        context.lastReported = propertyState;
        context.lastService = serviceState;

        const merged = {
            ...propertyState,
            _service_reported: serviceState,
            _area_definition: context.areaDefinition || {},
        };
        await this.updateStates(context, merged);
    }

    async ensureDeviceIotCredentials(context) {
        if (
            context.shadowClient &&
            context.iotCredentials &&
            (!context.iotCredentials.expiresAt || context.iotCredentials.expiresAt - Date.now() > 60000)
        ) {
            return;
        }
        try {
            const iotCredentials = await this.cloudClient.getDeviceIotCredentials(context.device.serialNumber);
            context.iotCredentials = iotCredentials;
            context.region = {
                ...context.region,
                regionName: iotCredentials.regionName || context.region.regionName,
                iotEndpoint: iotCredentials.endpoint || context.region.iotEndpoint,
                iotCredentials,
            };
            context.shadowClient = this.buildShadowClient(context.device, context.region, iotCredentials);
        } catch (error) {
            context.iotCredentials = null;
            context.shadowClient = null;
            throw new AnthbotGenieError(
                `Temporary IoT credentials are unavailable for ${context.device.serialNumber}; shadow access is disabled until the STS endpoint recovers: ${error.message}`,
            );
        }
    }

    buildShadowClient(device, region, iotCredentials) {
        return new AnthbotShadowApiClient({
            http: this.http,
            serialNumber: device.serialNumber,
            regionName: region.regionName,
            iotEndpoint: region.iotEndpoint,
            accountClient: this.cloudClient,
            iotCredentials,
            deviceModel: device.model,
        });
    }

    async updateStates(context, data) {
        const root = context.objectRoot;
        const updates = buildDeviceStateUpdates({
            context,
            data,
            eventCodeCache: this.eventCodeCache,
            errorDescriptionLanguage: this.anthbotConfig.errorDescriptionLanguage || 'English',
            now: new Date(),
        });

        for (const [suffix, value] of Object.entries(updates)) {
            await this.setStateAsync(`${root}.${suffix}`, { val: value, ack: true });
        }
    }

    async onStateChange(id, state) {
        if (!state || state.ack) {
            return;
        }

        const parts = id.replace(`${this.namespace}.`, '').split('.');
        if (parts.length < 3) {
            return;
        }

        const [objectRoot, section, ...commandParts] = parts;
        const command = commandParts.join('.');
        const context = this.deviceContextsByObjectRoot.get(objectRoot);
        if (!context) {
            this.log.warn(`No device context for state ${id}`);
            return;
        }

        let commandError = null;
        try {
            if (section === 'commands') {
                await this.handleCommandState(context, command, state.val);
            } else if (section === 'controls') {
                await this.handleControlState(context, command, state.val);
            } else if (section === 'consumable') {
                await this.handleConsumableState(context, command, state.val);
            }
        } catch (error) {
            commandError = error;
        } finally {
            try {
                await this.refreshDevice(context);
            } catch (refreshError) {
                this.log.warn(`Post-command refresh failed for ${id}: ${refreshError.message}`);
            }
            await this.resetWriteState(id, section, command, context);
        }

        if (commandError) {
            this.log.error(`Command failed for ${id}: ${commandError.message}`);
        }
    }

    async resetWriteState(id, section, command, context) {
        if (
            (section === 'commands' && BOOLEAN_COMMANDS.includes(command)) ||
            (section === 'consumable' && Object.hasOwn(MAINTENANCE_RESET_TYPES, command))
        ) {
            await this.setStateAsync(id, { val: false, ack: true });
            return;
        }
        if (section === 'commands' && STRING_COMMANDS.includes(command)) {
            await this.setStateAsync(id, { val: '', ack: true });
            return;
        }
        if (section === 'controls') {
            const fallbackValue = this.getControlFallbackValue(context, command);
            if (fallbackValue !== undefined) {
                await this.setStateAsync(id, { val: fallbackValue, ack: true });
            }
        }
    }

    getControlFallbackValue(context, control) {
        return getControlFallbackValue(context.lastReported || {}, control);
    }

    async handleCommandState(context, command, value) {
        const shouldRun =
            value === true || value === 1 || value === 'true' || (typeof value === 'string' && value.trim() !== '');
        if (!shouldRun) {
            return;
        }

        await this.ensureDeviceIotCredentials(context);
        const shouldRequestProperties = await this.executeCommand(context, command, value);
        if (shouldRequestProperties) {
            await context.shadowClient.requestAllProperties();
        }
        await this.delay(1000);
    }

    async handleControlState(context, control, value) {
        if (value === null || value === undefined || value === '') {
            return;
        }

        await this.ensureDeviceIotCredentials(context);
        await this.executeControl(context, control, value);
        await context.shadowClient.requestAllProperties();
        await this.delay(1000);
    }

    async handleConsumableState(context, command, value) {
        const shouldRun = value === true || value === 1 || value === 'true';
        if (!shouldRun) {
            return;
        }

        await this.ensureDeviceIotCredentials(context);
        await this.executeConsumableCommand(context, command);
        await this.delay(1000);
    }

    async executeCommand(context, command, value) {
        return executeCommand({ context, command, value });
    }

    async executeConsumableCommand(context, command) {
        await executeConsumableCommand({ context, command });
    }

    async executeControl(context, control, value) {
        await executeControl({ context, control, value });
    }

    delay(ms) {
        return new Promise(resolve => this.setTimeout(resolve, ms));
    }
}

if (require.main !== module) {
    module.exports = options => new AnthbotGenieAdapter(options);
} else {
    new AnthbotGenieAdapter();
}
